"use client"

import { useState, useEffect } from "react"
import {
  Search,
  Moon,
  Sun,
  Plus,
  Grid,
  List,
  LayoutGrid,
  Play,
  Heart,
  Trash2,
  Facebook,
  Instagram,
  Twitter,
  MessageCircle,
  Phone,
  Download,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { EnhancedLightbox } from "@/components/enhanced-lightbox"
import { AddMediaDialog } from "@/components/add-media-dialog"
import { DeveloperPanel } from "@/components/developer-panel"
import BlurText from "@/components/blur-text"
import ShopNameBlur from "@/components/shop-name-blur"
import HeroTitle from "@/components/hero-title"
import StarBorder from "@/components/star-border"

interface MediaItem {
  id: string
  title: string
  type: "image" | "video"
  url: string
  category: string
  tags: string[]
  description?: string
  isFavorite: boolean
  createdAt: Date
}

interface ContactInfo {
  phone: string
  facebook: string
  instagram: string
  twitter: string
  whatsapp: string
}

interface ThemeSettings {
  mode: "light" | "dark" | "auto"
  primaryColor: string
  secondaryColor: string
  fontFamily: string
  animationSpeed: number
}

export default function ZamzamGallery() {
  const [currentSection, setCurrentSection] = useState("home")
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([])
  const [filteredItems, setFilteredItems] = useState<MediaItem[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [viewMode, setViewMode] = useState("grid")
  const [isDeveloperMode, setIsDeveloperMode] = useState(false)
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isLightboxOpen, setIsLightboxOpen] = useState(false)
  const [currentLightboxIndex, setCurrentLightboxIndex] = useState(0)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [showInstallPrompt, setShowInstallPrompt] = useState(false)

  const [contactInfo, setContactInfo] = useState<ContactInfo>({
    phone: "+20 123 456 789",
    facebook: "https://facebook.com/zamzam",
    instagram: "https://instagram.com/zamzam",
    twitter: "https://twitter.com/zamzam",
    whatsapp: "+20123456789",
  })

  const [themeSettings, setThemeSettings] = useState<ThemeSettings>({
    mode: "light",
    primaryColor: "#667eea",
    secondaryColor: "#764ba2",
    fontFamily: "Cairo",
    animationSpeed: 1,
  })

  const [categories, setCategories] = useState([
    "طبيعة",
    "فضاء",
    "مناسبات",
    "سفر",
    "عام",
    "سباكة",
    "أدوات",
    "مشاريع",
    "أخرى",
  ])

  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false)
  const [passwordInput, setPasswordInput] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  // PWA Install Handler
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault()
      setDeferredPrompt(e)
      setShowInstallPrompt(true)
    }

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt)

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt)
    }
  }, [])

  const handleInstallClick = async () => {
    if (!deferredPrompt) return

    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === "accepted") {
      setShowInstallPrompt(false)
    }

    setDeferredPrompt(null)
  }

  const addCategory = (newCategory: string) => {
    if (newCategory && !categories.includes(newCategory)) {
      setCategories((prev) => [...prev, newCategory])
    }
  }

  const deleteCategory = (categoryToDelete: string) => {
    setCategories((prev) => prev.filter((cat) => cat !== categoryToDelete))
    setMediaItems((prev) =>
      prev.map((item) => (item.category === categoryToDelete ? { ...item, category: "أخرى" } : item)),
    )
  }

  const handlePasswordSubmit = () => {
    if (passwordInput === "zero") {
      setIsAuthenticated(true)
      setIsDeveloperMode(true)
      setIsPasswordModalOpen(false)
      setPasswordInput("")
    } else {
      alert("كلمة المرور غير صحيحة")
    }
  }

  // Apply theme settings
  useEffect(() => {
    const root = document.documentElement
    root.style.setProperty("--primary-color", themeSettings.primaryColor)
    root.style.setProperty("--secondary-color", themeSettings.secondaryColor)
    root.style.setProperty("--animation-speed", themeSettings.animationSpeed.toString())
    root.style.setProperty("--font-family", themeSettings.fontFamily)

    if (themeSettings.mode === "dark") {
      root.setAttribute("data-theme", "dark")
    } else {
      root.removeAttribute("data-theme")
    }
  }, [themeSettings])

  // Filter items based on search and category
  useEffect(() => {
    let filtered = mediaItems

    if (searchQuery) {
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (item.tags && item.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))) ||
          item.category.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((item) => item.category === selectedCategory)
    }

    setFilteredItems(filtered)
  }, [mediaItems, searchQuery, selectedCategory])

  const addMediaItem = (item: Omit<MediaItem, "id" | "createdAt">) => {
    const newItem: MediaItem = {
      ...item,
      id: Date.now().toString(),
      createdAt: new Date(),
    }
    setMediaItems((prev) => [newItem, ...prev])
  }

  const toggleFavorite = (id: string) => {
    setMediaItems((prev) => prev.map((item) => (item.id === id ? { ...item, isFavorite: !item.isFavorite } : item)))
  }

  const deleteItem = (id: string) => {
    setMediaItems((prev) => prev.filter((item) => item.id !== id))
  }

  const openLightbox = (index: number) => {
    setCurrentLightboxIndex(index)
    setIsLightboxOpen(true)
  }

  const stats = {
    totalImages: mediaItems.filter((item) => item.type === "image").length,
    totalVideos: mediaItems.filter((item) => item.type === "video").length,
    totalFavorites: mediaItems.filter((item) => item.isFavorite).length,
  }

  return (
    <div className="min-h-screen text-foreground relative" dir="rtl">
      {/* PWA Install Banner */}
      {showInstallPrompt && (
        <div className="fixed top-20 left-4 right-4 z-50 bg-primary text-primary-foreground p-4 rounded-lg shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold">تحميل التطبيق</h3>
              <p className="text-sm opacity-90">احصل على تجربة أفضل مع التطبيق</p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="secondary" onClick={handleInstallClick}>
                <Download className="h-4 w-4 ml-2" />
                تحميل
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setShowInstallPrompt(false)}>
                ✕
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-4 space-x-reverse">
              <ShopNameBlur className="text-2xl" delay={200} />
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
              {[
                { id: "home", label: "الرئيسية" },
                { id: "gallery", label: "المعرض" },
                { id: "about", label: "من نحن" },
                { id: "contact", label: "اتصل بنا" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setCurrentSection(item.id)}
                  className={`px-3 py-2 rounded-lg transition-colors ${
                    currentSection === item.id ? "bg-primary text-primary-foreground" : "hover:bg-muted"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center space-x-2 space-x-reverse">
              <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(!isSearchOpen)}>
                <Search className="h-4 w-4" />
              </Button>

              <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
                <DialogTrigger asChild>
                  <Button variant="default" size="sm">
                    <Plus className="h-4 w-4 ml-2" />
                    إضافة
                  </Button>
                </DialogTrigger>
                <AddMediaDialog onAdd={addMediaItem} categories={categories} />
              </Dialog>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setThemeSettings((prev) => ({
                    ...prev,
                    mode: prev.mode === "light" ? "dark" : "light",
                  }))
                }}
              >
                {themeSettings.mode === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
              </Button>

              <StarBorder as="div" color="#ff6b6b" speed="3s" thickness={1} className="inline-block">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => {
                    if (isAuthenticated) {
                      setIsDeveloperMode(!isDeveloperMode)
                    } else {
                      setIsPasswordModalOpen(true)
                    }
                  }}
                  className="bg-gradient-to-r from-red-500 to-orange-500 text-white border-0 transform hover:scale-110 transition-all duration-300"
                  style={{ transform: "rotateY(15deg)" }}
                >
                  <span className="font-mono font-bold">0</span>
                </Button>
              </StarBorder>
            </div>
          </div>

          {/* Search Bar */}
          {isSearchOpen && (
            <div className="py-4 border-t">
              <Input
                placeholder="ابحث..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="max-w-md"
              />
            </div>
          )}
        </div>
      </header>

      {/* Developer Panel */}
      {isDeveloperMode && isAuthenticated && (
        <DeveloperPanel
          themeSettings={themeSettings}
          onThemeChange={setThemeSettings}
          contactInfo={contactInfo}
          onContactChange={setContactInfo}
          categories={categories}
          onAddCategory={addCategory}
          onDeleteCategory={deleteCategory}
          onClose={() => setIsDeveloperMode(false)}
        />
      )}

      {/* Main Content */}
      <main className="pt-16 relative z-10">
        {currentSection === "home" && <HomeSection stats={stats} onNavigate={setCurrentSection} />}
        {currentSection === "gallery" && (
          <GallerySection
            items={filteredItems}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            categories={categories}
            onToggleFavorite={toggleFavorite}
            onDelete={deleteItem}
            onOpenLightbox={openLightbox}
          />
        )}
        {currentSection === "about" && <AboutSection />}
        {currentSection === "contact" && <ContactSection contactInfo={contactInfo} />}
      </main>

      {/* Footer */}
      <footer className="bg-muted/50 border-t mt-16 relative z-10">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-4 space-x-reverse">
              <a
                href={contactInfo.facebook}
                className="p-2 bg-blue-600 text-white rounded-full hover:scale-110 transition-transform"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href={contactInfo.instagram}
                className="p-2 bg-pink-600 text-white rounded-full hover:scale-110 transition-transform"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href={contactInfo.twitter}
                className="p-2 bg-blue-400 text-white rounded-full hover:scale-110 transition-transform"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href={`https://wa.me/${contactInfo.whatsapp}`}
                className="p-2 bg-green-600 text-white rounded-full hover:scale-110 transition-transform"
              >
                <MessageCircle className="h-4 w-4" />
              </a>
              <a
                href={`tel:${contactInfo.phone}`}
                className="p-2 bg-gray-600 text-white rounded-full hover:scale-110 transition-transform"
              >
                <Phone className="h-4 w-4" />
              </a>
            </div>
            <div className="text-center text-sm text-muted-foreground">
              © 2024 معرض زمزم zamzam - تم التطوير بواسطة عبدالله
            </div>
          </div>
        </div>
      </footer>

      {/* Lightbox */}
      {isLightboxOpen && (
        <EnhancedLightbox
          items={filteredItems}
          currentIndex={currentLightboxIndex}
          onClose={() => setIsLightboxOpen(false)}
          onNext={() => setCurrentLightboxIndex((prev) => (prev + 1) % filteredItems.length)}
          onPrev={() => setCurrentLightboxIndex((prev) => (prev - 1 + filteredItems.length) % filteredItems.length)}
          onToggleFavorite={toggleFavorite}
        />
      )}

      {/* Password Modal */}
      <Dialog open={isPasswordModalOpen} onOpenChange={setIsPasswordModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>أدخل كلمة المرور</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              type="password"
              placeholder="كلمة المرور"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handlePasswordSubmit()}
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsPasswordModalOpen(false)}>
                إلغاء
              </Button>
              <Button onClick={handlePasswordSubmit}>دخول</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Home Section Component
function HomeSection({ stats, onNavigate }: { stats: any; onNavigate: (section: string) => void }) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden py-20">
      <div className="container mx-auto px-4 text-center relative z-10">
        <HeroTitle />

        <BlurText
          text="معرض متخصص في أعمال السباكة والأدوات والمنتجات والمشاريع - استكشف مجموعة رائعة من الأعمال"
          className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto"
          delay={80}
          animateBy="words"
          direction="top"
          stepDuration={0.4}
        />

        {/* Stats */}
        <div className="flex justify-center gap-8 mb-12">
          <div className="text-center glass-effect p-4 rounded-lg">
            <div className="text-4xl font-bold text-primary">{stats.totalImages}</div>
            <div className="text-muted-foreground">صورة</div>
          </div>
          <div className="text-center glass-effect p-4 rounded-lg">
            <div className="text-4xl font-bold text-secondary">{stats.totalVideos}</div>
            <div className="text-muted-foreground">فيديو</div>
          </div>
          <div className="text-center glass-effect p-4 rounded-lg">
            <div className="text-4xl font-bold text-accent">{stats.totalFavorites}</div>
            <div className="text-muted-foreground">مفضلة</div>
          </div>
        </div>

        {/* CTA Buttons with StarBorder */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <StarBorder as="div" color="#667eea" speed="4s" thickness={2} className="inline-block">
            <Button
              size="lg"
              onClick={() => onNavigate("gallery")}
              className="text-lg px-8 py-4 bg-transparent border-0"
            >
              <Grid className="ml-2 h-5 w-5" />
              استكشف المعرض
            </Button>
          </StarBorder>

          <StarBorder as="div" color="#764ba2" speed="5s" thickness={2} className="inline-block">
            <Button
              size="lg"
              variant="outline"
              onClick={() => onNavigate("contact")}
              className="text-lg px-8 py-4 bg-transparent"
            >
              <Phone className="ml-2 h-5 w-5" />
              اتصل بنا
            </Button>
          </StarBorder>
        </div>
      </div>
    </section>
  )
}

// Gallery Section Component
function GallerySection({
  items,
  viewMode,
  onViewModeChange,
  selectedCategory,
  onCategoryChange,
  categories,
  onToggleFavorite,
  onDelete,
  onOpenLightbox,
}: any) {
  return (
    <section className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <h2 className="text-3xl font-bold">المعرض</h2>
        <div className="flex flex-wrap gap-4">
          <Select value={selectedCategory} onValueChange={onCategoryChange}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="اختر فئة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">الكل</SelectItem>
              {categories.map((category: string) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex border rounded-lg">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => onViewModeChange("grid")}
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => onViewModeChange("list")}
            >
              <List className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "masonry" ? "default" : "ghost"}
              size="sm"
              onClick={() => onViewModeChange("masonry")}
            >
              <LayoutGrid className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-16">
          <div className="text-6xl mb-4">📷</div>
          <h3 className="text-2xl font-semibold mb-2">لا توجد عناصر لعرضها</h3>
          <p className="text-muted-foreground mb-4">جرب تغيير الفئة أو كلمة البحث</p>
          <Button>
            <Plus className="ml-2 h-4 w-4" />
            إضافة وسائط جديدة
          </Button>
        </div>
      ) : (
        <div
          className={`grid gap-6 ${
            viewMode === "grid"
              ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
              : viewMode === "list"
                ? "grid-cols-1"
                : "masonry"
          }`}
        >
          {items.map((item: MediaItem, index: number) => (
            <Card
              key={item.id}
              className={`${viewMode === "masonry" ? "masonry-item" : ""} card-3d group overflow-hidden hover:shadow-2xl transition-all duration-500`}
            >
              <div className="relative">
                {item.type === "image" ? (
                  <img
                    src={item.url || "/placeholder.svg?height=200&width=300"}
                    alt={item.title}
                    className="w-full h-48 object-cover cursor-pointer"
                    onClick={() => onOpenLightbox(index)}
                  />
                ) : (
                  <video
                    src={item.url}
                    className="w-full h-48 object-cover cursor-pointer"
                    onClick={() => onOpenLightbox(index)}
                  />
                )}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Button size="sm" variant="secondary">
                    <Play className="h-4 w-4" />
                  </Button>
                </div>
                <div className="absolute top-2 right-2 flex gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="bg-white/80 hover:bg-white"
                    onClick={() => onToggleFavorite(item.id)}
                  >
                    <Heart className={`h-4 w-4 ${item.isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="bg-white/80 hover:bg-white"
                    onClick={() => onDelete(item.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <Badge variant="secondary" className="mb-2">
                  {item.category}
                </Badge>
                {item.description && <p className="text-sm text-muted-foreground mb-2">{item.description}</p>}
                {item.tags && (
                  <div className="flex flex-wrap gap-1">
                    {item.tags.map((tag: string) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </section>
  )
}

// About Section Component
function AboutSection() {
  return (
    <section className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-bold mb-8">حول معرض زمزم</h2>
        <p className="text-xl text-muted-foreground mb-12 leading-relaxed">
          معرض زمزم متخصص في أعمال السباكة والأدوات والمشاريع المتنوعة. نقدم خدمات عالية الجودة ونعرض أعمالنا المميزة من
          خلال هذا المعرض الرقمي
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { icon: "🛠️", title: "أدوات متخصصة", desc: "أحدث الأدوات والمعدات" },
            { icon: "🔧", title: "تركيب محترف", desc: "تركيب وصيانة الأدوات" },
            { icon: "🏗️", title: "مشاريع متنوعة", desc: "مشاريع سكنية وتجارية" },
            { icon: "⭐", title: "جودة عالية", desc: "العمل بأعلى معايير الجودة" },
          ].map((feature, index) => (
            <Card key={index} className="p-6 text-center hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.desc}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

// Contact Section Component
function ContactSection({ contactInfo }: { contactInfo: ContactInfo }) {
  return (
    <section className="container mx-auto px-4 py-16">
      <div className="max-w-2xl mx-auto text-center">
        <h2 className="text-4xl font-bold mb-8">تواصل معنا</h2>
        <p className="text-xl text-muted-foreground mb-12">لطلب خدمة أو استفسار، لا تتردد في التواصل معنا</p>
        <div className="grid gap-6">
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-full">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <div className="text-right">
                <h3 className="font-semibold">رقم الهاتف</h3>
                <p className="text-muted-foreground">{contactInfo.phone}</p>
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-500/10 rounded-full">
                <MessageCircle className="h-6 w-6 text-green-500" />
              </div>
              <div className="text-right">
                <h3 className="font-semibold">واتساب</h3>
                <p className="text-muted-foreground">{contactInfo.whatsapp}</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
