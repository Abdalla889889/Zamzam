import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import Particles from "@/components/particles"
import { Background } from "@/components/background"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "معرض زمزم - Zamzam Gallery",
  description: "معرض متخصص في أعمال السباكة والأدوات والمشاريع",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "معرض زمزم",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    type: "website",
    siteName: "معرض زمزم",
    title: "معرض زمزم - Zamzam Gallery",
    description: "معرض متخصص في أعمال السباكة والأدوات والمشاريع",
  },
  twitter: {
    card: "summary",
    title: "معرض زمزم - Zamzam Gallery",
    description: "معرض متخصص في أعمال السباكة والأدوات والمشاريع",
  },
    generator: 'v0.dev'
}

export const viewport: Viewport = {
  themeColor: "#764ba2",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/icon-192x192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="معرض زمزم" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="msapplication-TileColor" content="#764ba2" />
        <meta name="msapplication-tap-highlight" content="no" />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {/* Multi-layered Background System */}
          <Background />

          {/* Enhanced Particles Layer */}
          <Particles
            particleCount={350}
            particleSpread={45}
            speed={0.6}
            particleColors={[
              "#ff6b6b",
              "#4ecdc4",
              "#45b7d1",
              "#96ceb4",
              "#feca57",
              "#ff9ff3",
              "#54a0ff",
              "#5f27cd",
              "#00d2d3",
              "#ff9f43",
              "#ee5a24",
              "#0abde3",
              "#10ac84",
              "#fd79a8",
              "#fdcb6e",
              "#6c5ce7",
            ]}
            moveParticlesOnHover={true}
            particleHoverFactor={0.7}
            alphaParticles={true}
            particleBaseSize={6}
            sizeRandomness={4}
            className="opacity-40"
          />

          {/* Content Overlay */}
          <div className="content-overlay">{children}</div>

          <Toaster />

          {/* PWA Install Script */}
          <script
            dangerouslySetInnerHTML={{
              __html: `
                if ('serviceWorker' in navigator) {
                  window.addEventListener('load', function() {
                    navigator.serviceWorker.register('/sw.js')
                      .then(function(registration) {
                        console.log('SW registered: ', registration);
                      })
                      .catch(function(registrationError) {
                        console.log('SW registration failed: ', registrationError);
                      });
                  });
                }
              `,
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  )
}
