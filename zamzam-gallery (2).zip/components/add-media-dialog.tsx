"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Upload, X, Link } from "lucide-react"
import { FileUpload } from "./file-upload"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface MediaItem {
  title: string
  type: "image" | "video"
  url: string
  category: string
  tags: string[]
  description?: string
  isFavorite: boolean
}

interface AddMediaDialogProps {
  onAdd: (item: MediaItem) => void
  categories: string[]
}

export function AddMediaDialog({ onAdd, categories }: AddMediaDialogProps) {
  const [formData, setFormData] = useState({
    title: "",
    type: "image" as "image" | "video",
    url: "",
    category: "",
    description: "",
    tags: [] as string[],
  })
  const [newTag, setNewTag] = useState("")
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [uploadMethod, setUploadMethod] = useState<"url" | "file">("file")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (uploadMethod === "file" && selectedFiles.length > 0) {
      selectedFiles.forEach((file) => {
        const fileUrl = URL.createObjectURL(file)
        const fileType = file.type.startsWith("image/") ? "image" : "video"

        onAdd({
          title: formData.title || file.name,
          type: fileType,
          url: fileUrl,
          category: formData.category,
          description: formData.description,
          tags: formData.tags,
          isFavorite: false,
        })
      })
    } else if (uploadMethod === "url" && formData.title && formData.url && formData.category) {
      onAdd({
        ...formData,
        isFavorite: false,
      })
    }

    setFormData({
      title: "",
      type: "image",
      url: "",
      category: "",
      description: "",
      tags: [],
    })
    setSelectedFiles([])
  }

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()],
      }))
      setNewTag("")
    }
  }

  const removeTag = (tagToRemove: string) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((tag) => tag !== tagToRemove),
    }))
  }

  const handleFileSelect = (files: File[]) => {
    setSelectedFiles(files)
    if (files.length > 0 && !formData.title) {
      setFormData((prev) => ({
        ...prev,
        title: files[0].name.replace(/\.[^/.]+$/, ""),
        type: files[0].type.startsWith("image/") ? "image" : "video",
      }))
    }
  }

  return (
    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>إضافة وسائط جديدة</DialogTitle>
      </DialogHeader>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Tabs value={uploadMethod} onValueChange={(value) => setUploadMethod(value as "url" | "file")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="file" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              تحميل ملف
            </TabsTrigger>
            <TabsTrigger value="url" className="flex items-center gap-2">
              <Link className="h-4 w-4" />
              رابط
            </TabsTrigger>
          </TabsList>

          <TabsContent value="file" className="space-y-4">
            <FileUpload
              onFileSelect={handleFileSelect}
              accept="image/*,video/*"
              multiple={true}
              maxSize={100}
              className="w-full"
            />
          </TabsContent>

          <TabsContent value="url" className="space-y-4">
            <div>
              <Label htmlFor="type">النوع</Label>
              <Select
                value={formData.type}
                onValueChange={(value: "image" | "video") => setFormData((prev) => ({ ...prev, type: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="image">صورة</SelectItem>
                  <SelectItem value="video">فيديو</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="url">رابط الملف</Label>
              <Input
                id="url"
                type="url"
                value={formData.url}
                onChange={(e) => setFormData((prev) => ({ ...prev, url: e.target.value }))}
                placeholder="https://example.com/image.jpg"
                required={uploadMethod === "url"}
              />
            </div>
          </TabsContent>
        </Tabs>

        <div>
          <Label htmlFor="title">العنوان</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData((prev) => ({ ...prev, title: e.target.value }))}
            placeholder="عنوان الوسائط"
            required
          />
        </div>

        <div>
          <Label htmlFor="category">الفئة</Label>
          <Select
            value={formData.category}
            onValueChange={(value) => setFormData((prev) => ({ ...prev, category: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="اختر فئة" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="description">الوصف (اختياري)</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
            placeholder="وصف الوسائط..."
            rows={3}
          />
        </div>

        <div>
          <Label>العلامات</Label>
          <div className="flex gap-2 mb-2">
            <Input
              value={newTag}
              onChange={(e) => setNewTag(e.target.value)}
              placeholder="إضافة علامة"
              onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
            />
            <Button type="button" onClick={addTag} size="sm">
              إضافة
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {formData.tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                {tag}
                <Button type="button" variant="ghost" size="sm" className="h-4 w-4 p-0" onClick={() => removeTag(tag)}>
                  <X className="h-3 w-3" />
                </Button>
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button
            type="submit"
            disabled={
              !formData.category ||
              (uploadMethod === "url" && (!formData.title || !formData.url)) ||
              (uploadMethod === "file" && selectedFiles.length === 0)
            }
          >
            <Upload className="h-4 w-4 ml-2" />
            إضافة
          </Button>
        </div>
      </form>
    </DialogContent>
  )
}
