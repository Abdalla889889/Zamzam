"use client"

import { useEffect, useState } from "react"

interface BackgroundProps {
  className?: string
}

export function Background({ className = "" }: BackgroundProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <>
      {/* Main Animated Gradient Background */}
      <div className="main-background" />

      {/* Overlay Pattern */}
      <div className="background-overlay" />

      {/* Geometric Shapes */}
      <div className="geometric-shapes">
        <div className="shape shape-1" />
        <div className="shape shape-2" />
        <div className="shape shape-3" />
        <div className="shape shape-4" />
        <div className="shape shape-5" />
      </div>
    </>
  )
}
