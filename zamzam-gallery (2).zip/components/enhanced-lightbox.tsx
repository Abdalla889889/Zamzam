"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X, ChevronLeft, ChevronRight, Heart, Download } from "lucide-react"

interface MediaItem {
  id: string
  title: string
  type: "image" | "video"
  url: string
  category: string
  tags?: string[]
  description?: string
  isFavorite: boolean
  createdAt: Date
}

interface EnhancedLightboxProps {
  items: MediaItem[]
  currentIndex: number
  onClose: () => void
  onNext: () => void
  onPrev: () => void
  onToggleFavorite: (id: string) => void
}

export function EnhancedLightbox({
  items,
  currentIndex,
  onClose,
  onNext,
  onPrev,
  onToggleFavorite,
}: EnhancedLightboxProps) {
  const currentItem = items[currentIndex]

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case "Escape":
          onClose()
          break
        case "ArrowLeft":
          onNext()
          break
        case "ArrowRight":
          onPrev()
          break
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [onClose, onNext, onPrev])

  if (!currentItem) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center">
      <div className="relative w-full h-full flex items-center justify-center p-4">
        {/* Close Button */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 z-10 bg-white/10 hover:bg-white/20 text-white"
          onClick={onClose}
        >
          <X className="h-6 w-6" />
        </Button>

        {/* Navigation Buttons */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-white/10 hover:bg-white/20 text-white"
          onClick={onPrev}
          disabled={items.length <= 1}
        >
          <ChevronLeft className="h-8 w-8" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-white/10 hover:bg-white/20 text-white"
          onClick={onNext}
          disabled={items.length <= 1}
        >
          <ChevronRight className="h-8 w-8" />
        </Button>

        {/* Media Content */}
        <div className="max-w-4xl max-h-full flex flex-col items-center">
          {currentItem.type === "image" ? (
            <img
              src={currentItem.url || "/placeholder.svg"}
              alt={currentItem.title}
              className="max-w-full max-h-[70vh] object-contain rounded-lg"
            />
          ) : (
            <video src={currentItem.url} controls className="max-w-full max-h-[70vh] object-contain rounded-lg" />
          )}

          {/* Media Info */}
          <div className="mt-4 text-center text-white max-w-2xl">
            <h3 className="text-2xl font-bold mb-2">{currentItem.title}</h3>
            {currentItem.description && <p className="text-gray-300 mb-4">{currentItem.description}</p>}

            <div className="flex flex-wrap justify-center gap-2 mb-4">
              <Badge variant="secondary">{currentItem.category}</Badge>
              {currentItem.tags?.map((tag) => (
                <Badge key={tag} variant="outline" className="text-white border-white/30">
                  {tag}
                </Badge>
              ))}
            </div>

            <div className="flex justify-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20"
                onClick={() => onToggleFavorite(currentItem.id)}
              >
                <Heart className={`h-4 w-4 ml-2 ${currentItem.isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                {currentItem.isFavorite ? "إزالة من المفضلة" : "إضافة للمفضلة"}
              </Button>

              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20"
                onClick={() => {
                  const link = document.createElement("a")
                  link.href = currentItem.url
                  link.download = currentItem.title
                  link.click()
                }}
              >
                <Download className="h-4 w-4 ml-2" />
                تحميل
              </Button>
            </div>
          </div>
        </div>

        {/* Counter */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white bg-black/50 px-4 py-2 rounded-full">
          {currentIndex + 1} من {items.length}
        </div>
      </div>
    </div>
  )
}
