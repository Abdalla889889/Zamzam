"use client"

import { motion } from "framer-motion"
import { useEffect, useRef, useState } from "react"

interface ShopNameBlurProps {
  className?: string
  delay?: number
}

const ShopNameBlur = ({ className = "", delay = 300 }: ShopNameBlurProps) => {
  const [inView, setInView] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!ref.current) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true)
          observer.unobserve(ref.current!)
        }
      },
      { threshold: 0.1, rootMargin: "0px" },
    )

    observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  const words = ["معرض", "زمزم", "zamzam"]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: delay / 1000,
        delayChildren: 0.2,
      },
    },
  }

  const wordVariants = {
    hidden: {
      opacity: 0,
      filter: "blur(10px)",
      y: -20,
      scale: 0.8,
    },
    visible: {
      opacity: 1,
      filter: "blur(0px)",
      y: 0,
      scale: 1,
      transition: {
        duration: 0.8,
        ease: [0.25, 0.46, 0.45, 0.94],
        filter: {
          duration: 1.2,
        },
      },
    },
  }

  return (
    <motion.div
      ref={ref}
      className={`flex flex-wrap items-center gap-2 ${className}`}
      variants={containerVariants}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
    >
      {words.map((word, index) => (
        <motion.span
          key={index}
          variants={wordVariants}
          className="inline-block will-change-[transform,filter,opacity] font-bold"
          style={{
            background: "linear-gradient(135deg, var(--primary-color), var(--secondary-color))",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
          }}
        >
          {word}
        </motion.span>
      ))}
    </motion.div>
  )
}

export default ShopNameBlur
