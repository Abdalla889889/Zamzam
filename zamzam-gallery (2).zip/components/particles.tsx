"use client"

import { useEffect, useRef } from "react"
import "./particles.css"

interface ParticlesProps {
  particleCount?: number
  particleSpread?: number
  speed?: number
  particleColors?: string[]
  moveParticlesOnHover?: boolean
  particleHoverFactor?: number
  alphaParticles?: boolean
  particleBaseSize?: number
  sizeRandomness?: number
  cameraDistance?: number
  disableRotation?: boolean
  className?: string
}

const defaultColors = [
  "#ff6b6b",
  "#4ecdc4",
  "#45b7d1",
  "#96ceb4",
  "#feca57",
  "#ff9ff3",
  "#54a0ff",
  "#5f27cd",
  "#00d2d3",
  "#ff9f43",
  "#ee5a24",
  "#0abde3",
  "#10ac84",
  "#fd79a8",
  "#fdcb6e",
  "#6c5ce7",
  "#a55eea",
  "#26de81",
  "#fc5c65",
  "#fed330",
  "#2bcbba",
  "#eb3b5a",
  "#fa8231",
  "#f7b731",
  "#20bf6b",
  "#0fb9b1",
  "#45aaf2",
  "#4b7bec",
  "#a55eea",
]

const Particles = ({
  particleCount = 350,
  particleSpread = 45,
  speed = 0.6,
  particleColors,
  moveParticlesOnHover = true,
  particleHoverFactor = 0.7,
  alphaParticles = true,
  particleBaseSize = 6,
  sizeRandomness = 4,
  cameraDistance = 20,
  disableRotation = false,
  className = "",
}: ParticlesProps) => {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const mouseRef = useRef({ x: 0, y: 0 })
  const animationRef = useRef<number>()

  useEffect(() => {
    const container = containerRef.current
    const canvas = canvasRef.current
    if (!container || !canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resize = () => {
      const width = window.innerWidth
      const height = window.innerHeight
      canvas.width = width
      canvas.height = height
    }

    window.addEventListener("resize", resize)
    resize()

    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth) * 2 - 1
      const y = -((e.clientY / window.innerHeight) * 2 - 1)
      mouseRef.current = { x, y }
    }

    if (moveParticlesOnHover) {
      window.addEventListener("mousemove", handleMouseMove)
    }

    // Initialize particles
    const palette = particleColors && particleColors.length > 0 ? particleColors : defaultColors
    const particles: any[] = []

    for (let i = 0; i < particleCount; i++) {
      let x, y, z, len
      do {
        x = Math.random() * 2 - 1
        y = Math.random() * 2 - 1
        z = Math.random() * 2 - 1
        len = x * x + y * y + z * z
      } while (len > 1 || len === 0)

      const r = Math.cbrt(Math.random())
      const color = palette[Math.floor(Math.random() * palette.length)]
      const size = particleBaseSize * (1 + Math.random() * sizeRandomness)

      particles.push({
        x: x * r * particleSpread,
        y: y * r * particleSpread,
        z: z * r * particleSpread,
        originalX: x * r * particleSpread,
        originalY: y * r * particleSpread,
        originalZ: z * r * particleSpread,
        color,
        size,
        random: Math.random(),
        phase: Math.random() * Math.PI * 2,
        pulseSpeed: 0.02 + Math.random() * 0.04,
        rotationSpeed: (Math.random() - 0.5) * 0.02,
        twinklePhase: Math.random() * Math.PI * 2,
      })
    }

    let lastTime = performance.now()
    let elapsed = 0

    const update = (t: number) => {
      const delta = t - lastTime
      lastTime = t
      elapsed += delta * speed

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      const centerX = canvas.width / 2
      const centerY = canvas.height / 2

      particles.forEach((particle, index) => {
        // Apply mouse movement
        let x = particle.originalX
        let y = particle.originalY

        if (moveParticlesOnHover) {
          x += mouseRef.current.x * particleHoverFactor * 120
          y += mouseRef.current.y * particleHoverFactor * 120
        }

        // Apply rotation
        if (!disableRotation) {
          const rotationZ = elapsed * 0.0008 * speed + particle.rotationSpeed * elapsed

          const cosZ = Math.cos(rotationZ + index * 0.1)
          const sinZ = Math.sin(rotationZ + index * 0.1)
          const newX = x * cosZ - y * sinZ
          const newY = x * sinZ + y * cosZ

          x = newX
          y = newY
        }

        // Enhanced floating animation
        const floatY = Math.sin(elapsed * 0.002 + particle.phase) * 35
        const floatX = Math.cos(elapsed * 0.0015 + particle.phase) * 30

        // Project to screen space
        const screenX = centerX + x * 22 + floatX
        const screenY = centerY + y * 22 + floatY

        // Enhanced pulsing size with twinkle effect
        const pulseSize = particle.size + Math.sin(elapsed * particle.pulseSpeed + particle.phase) * 2.5
        const twinkle = Math.sin(elapsed * 0.005 + particle.twinklePhase) * 0.5 + 0.5

        // Draw particle with enhanced glow effect
        ctx.save()

        // Outer glow (largest)
        const outerGradient = ctx.createRadialGradient(screenX, screenY, 0, screenX, screenY, pulseSize * 10)
        outerGradient.addColorStop(
          0,
          particle.color +
            Math.floor(100 * twinkle)
              .toString(16)
              .padStart(2, "0"),
        )
        outerGradient.addColorStop(
          0.2,
          particle.color +
            Math.floor(60 * twinkle)
              .toString(16)
              .padStart(2, "0"),
        )
        outerGradient.addColorStop(
          0.5,
          particle.color +
            Math.floor(30 * twinkle)
              .toString(16)
              .padStart(2, "0"),
        )
        outerGradient.addColorStop(1, particle.color + "00")

        ctx.fillStyle = outerGradient
        ctx.beginPath()
        ctx.arc(screenX, screenY, pulseSize * 10, 0, Math.PI * 2)
        ctx.fill()

        // Middle glow
        const middleGradient = ctx.createRadialGradient(screenX, screenY, 0, screenX, screenY, pulseSize * 5)
        middleGradient.addColorStop(0, particle.color + "B0")
        middleGradient.addColorStop(0.5, particle.color + "80")
        middleGradient.addColorStop(1, particle.color + "00")

        ctx.fillStyle = middleGradient
        ctx.beginPath()
        ctx.arc(screenX, screenY, pulseSize * 5, 0, Math.PI * 2)
        ctx.fill()

        // Inner particle
        ctx.globalAlpha = alphaParticles ? 0.9 + twinkle * 0.1 : 1
        ctx.fillStyle = particle.color
        ctx.beginPath()
        ctx.arc(screenX, screenY, pulseSize, 0, Math.PI * 2)
        ctx.fill()

        // Inner bright core
        ctx.fillStyle = "#ffffff"
        ctx.globalAlpha = 0.8 + twinkle * 0.2
        ctx.beginPath()
        ctx.arc(screenX, screenY, pulseSize * 0.6, 0, Math.PI * 2)
        ctx.fill()

        // Enhanced sparkle effect
        if (Math.random() < 0.04) {
          ctx.fillStyle = "#ffffff"
          ctx.globalAlpha = 1
          ctx.beginPath()
          ctx.arc(
            screenX + (Math.random() - 0.5) * pulseSize * 4,
            screenY + (Math.random() - 0.5) * pulseSize * 4,
            Math.random() * 3,
            0,
            Math.PI * 2,
          )
          ctx.fill()
        }

        ctx.restore()
      })

      animationRef.current = requestAnimationFrame(update)
    }

    animationRef.current = requestAnimationFrame(update)

    return () => {
      window.removeEventListener("resize", resize)
      if (moveParticlesOnHover) {
        window.removeEventListener("mousemove", handleMouseMove)
      }
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [
    particleCount,
    particleSpread,
    speed,
    moveParticlesOnHover,
    particleHoverFactor,
    alphaParticles,
    particleBaseSize,
    sizeRandomness,
    cameraDistance,
    disableRotation,
    particleColors,
  ])

  return (
    <div ref={containerRef} className={`particles-container ${className}`}>
      <canvas ref={canvasRef} />
    </div>
  )
}

export default Particles
