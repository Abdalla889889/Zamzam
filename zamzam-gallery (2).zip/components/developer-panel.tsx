"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { CategoryManager } from "@/components/category-manager"
import { X, Settings, Palette, Phone } from "lucide-react"

interface ThemeSettings {
  mode: "light" | "dark" | "auto"
  primaryColor: string
  secondaryColor: string
  fontFamily: string
  animationSpeed: number
}

interface ContactInfo {
  phone: string
  facebook: string
  instagram: string
  twitter: string
  whatsapp: string
}

interface DeveloperPanelProps {
  themeSettings: ThemeSettings
  onThemeChange: (settings: ThemeSettings) => void
  contactInfo: ContactInfo
  onContactChange: (info: ContactInfo) => void
  categories: string[]
  onAddCategory: (category: string) => void
  onDeleteCategory: (category: string) => void
  onClose: () => void
}

export function DeveloperPanel({
  themeSettings,
  onThemeChange,
  contactInfo,
  onContactChange,
  categories,
  onAddCategory,
  onDeleteCategory,
  onClose,
}: DeveloperPanelProps) {
  const [activeTab, setActiveTab] = useState("theme")

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-background border rounded-lg shadow-lg max-w-2xl w-full max-h-[90vh] overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Settings className="h-5 w-5" />
            لوحة المطور
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex border-b">
          {[
            { id: "theme", label: "المظهر", icon: Palette },
            { id: "contact", label: "التواصل", icon: Phone },
            { id: "categories", label: "الفئات", icon: Settings },
          ].map((tab) => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "ghost"}
              className="rounded-none"
              onClick={() => setActiveTab(tab.id)}
            >
              <tab.icon className="h-4 w-4 ml-2" />
              {tab.label}
            </Button>
          ))}
        </div>

        <div className="p-4 overflow-y-auto max-h-[60vh]">
          {activeTab === "theme" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>إعدادات المظهر</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>وضع المظهر</Label>
                    <Select
                      value={themeSettings.mode}
                      onValueChange={(value: "light" | "dark" | "auto") =>
                        onThemeChange({ ...themeSettings, mode: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">فاتح</SelectItem>
                        <SelectItem value="dark">داكن</SelectItem>
                        <SelectItem value="auto">تلقائي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>اللون الأساسي</Label>
                    <Input
                      type="color"
                      value={themeSettings.primaryColor}
                      onChange={(e) => onThemeChange({ ...themeSettings, primaryColor: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label>اللون الثانوي</Label>
                    <Input
                      type="color"
                      value={themeSettings.secondaryColor}
                      onChange={(e) => onThemeChange({ ...themeSettings, secondaryColor: e.target.value })}
                    />
                  </div>

                  <div>
                    <Label>سرعة الحركة: {themeSettings.animationSpeed}x</Label>
                    <Slider
                      value={[themeSettings.animationSpeed]}
                      onValueChange={([value]) => onThemeChange({ ...themeSettings, animationSpeed: value })}
                      min={0.5}
                      max={2}
                      step={0.1}
                      className="mt-2"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "contact" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>معلومات التواصل</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>رقم الهاتف</Label>
                    <Input
                      value={contactInfo.phone}
                      onChange={(e) => onContactChange({ ...contactInfo, phone: e.target.value })}
                      placeholder="+20 123 456 789"
                    />
                  </div>

                  <div>
                    <Label>فيسبوك</Label>
                    <Input
                      value={contactInfo.facebook}
                      onChange={(e) => onContactChange({ ...contactInfo, facebook: e.target.value })}
                      placeholder="https://facebook.com/username"
                    />
                  </div>

                  <div>
                    <Label>إنستغرام</Label>
                    <Input
                      value={contactInfo.instagram}
                      onChange={(e) => onContactChange({ ...contactInfo, instagram: e.target.value })}
                      placeholder="https://instagram.com/username"
                    />
                  </div>

                  <div>
                    <Label>تويتر</Label>
                    <Input
                      value={contactInfo.twitter}
                      onChange={(e) => onContactChange({ ...contactInfo, twitter: e.target.value })}
                      placeholder="https://twitter.com/username"
                    />
                  </div>

                  <div>
                    <Label>واتساب</Label>
                    <Input
                      value={contactInfo.whatsapp}
                      onChange={(e) => onContactChange({ ...contactInfo, whatsapp: e.target.value })}
                      placeholder="+20123456789"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "categories" && (
            <CategoryManager
              categories={categories}
              onAddCategory={onAddCategory}
              onDeleteCategory={onDeleteCategory}
            />
          )}
        </div>
      </div>
    </div>
  )
}
