"use client"

import { motion } from "framer-motion"
import { useEffect, useRef, useState } from "react"

const HeroTitle = () => {
  const [inView, setInView] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!ref.current) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true)
          observer.unobserve(ref.current!)
        }
      },
      { threshold: 0.1 },
    )

    observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  const titleWords = ["مرحبًا", "بكم", "في", "معرض", "زمزم", "zamzam"]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const wordVariants = {
    hidden: {
      opacity: 0,
      filter: "blur(15px)",
      y: -30,
      rotateX: -90,
      scale: 0.5,
    },
    visible: {
      opacity: 1,
      filter: "blur(0px)",
      y: 0,
      rotateX: 0,
      scale: 1,
      transition: {
        duration: 1,
        ease: [0.25, 0.46, 0.45, 0.94],
        filter: {
          duration: 1.5,
        },
      },
    },
  }

  const highlightVariants = {
    hidden: {
      opacity: 0,
      filter: "blur(20px)",
      scale: 0.3,
      rotateY: 180,
    },
    visible: {
      opacity: 1,
      filter: "blur(0px)",
      scale: 1,
      rotateY: 0,
      transition: {
        duration: 1.5,
        ease: [0.25, 0.46, 0.45, 0.94],
        delay: 1,
      },
    },
  }

  return (
    <motion.div
      ref={ref}
      className="text-center mb-8"
      variants={containerVariants}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
    >
      <motion.div className="flex flex-wrap justify-center items-center gap-3 mb-4">
        {titleWords.map((word, index) => {
          const isHighlight = word === "زمزم" || word === "zamzam"

          return (
            <motion.span
              key={index}
              variants={isHighlight ? highlightVariants : wordVariants}
              className={`inline-block will-change-[transform,filter,opacity] font-bold text-5xl md:text-7xl ${
                isHighlight
                  ? "bg-gradient-to-r from-yellow-400 via-red-500 to-pink-500 bg-clip-text text-transparent drop-shadow-lg"
                  : "bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent"
              }`}
              style={{
                transformStyle: "preserve-3d",
                ...(isHighlight && {
                  textShadow: "0 0 20px rgba(255, 215, 0, 0.5)",
                  filter: "drop-shadow(0 0 10px rgba(255, 215, 0, 0.3))",
                }),
              }}
            >
              {word}
            </motion.span>
          )
        })}
      </motion.div>

      {/* Decorative elements */}
      <motion.div
        className="flex justify-center gap-2 mt-4"
        initial={{ opacity: 0, scale: 0 }}
        animate={inView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
        transition={{ delay: 2, duration: 0.8 }}
      >
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="w-2 h-2 bg-gradient-to-r from-primary to-secondary rounded-full"
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Number.POSITIVE_INFINITY,
              delay: i * 0.3,
            }}
          />
        ))}
      </motion.div>
    </motion.div>
  )
}

export default HeroTitle
